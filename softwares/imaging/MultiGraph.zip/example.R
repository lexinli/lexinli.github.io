rm(list = ls())
source("util_funcs.R")
source("group_glasso.R")
source("graph.generator.R")
source("data.generater.R")
source("generate.roc.R")
require(Matrix)
require(sand)

sample.size <- rep(10,2)
m.time <- rep(20,2)
n.loc = 30
K = 2
lam <- exp(seq(-3,3,length.out=20))*sqrt(log(n.loc)/(m.time*sample.size))
nu <- c(0,exp(seq(-2,2,length.out=4))*sqrt(log(n.loc)/(m.time*sample.size)))


tmp <- multi.graph.generator(m.time,n.loc,spatial.graph="band")
omega.0 = tmp$omega.loc 
data <- data.generator(sample.size,tmp$S.time,tmp$S.loc)
omega.cv <- group.cv.constrained(data,lam,nu,R=200)
omega.mean <- omega.cv$omega.mean
perf <- performance(omega.0,omega.mean)
cat("FP:", perf$fp,", FN:", perf$fn,", Eloss:",perf$Eloss,", Qloss:",perf$Qloss,"\n")
