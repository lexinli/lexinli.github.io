function [Btil, Bhat] = Tenv(Yn,Xn,u)
ss = size(Yn);
n = ss(end);
r = ss(1:end-1);
m = length(r);
prodr = prod(r);
p = size(Xn,1);
mux = mean(Xn,2);
Xn = Xn - mux(:,ones(n,1));
muy = mean(double(Yn),m+1);
if m==2
    Yn = tensor(double(Yn)-muy(:,:,ones(n,1)));
elseif m==3
    Yn = tensor(double(Yn)-muy(:,:,:,ones(n,1)));
elseif m==4
    Yn = tensor(double(Yn)-muy(:,:,:,:,ones(n,1)));
end
Btil = ttm(Yn,pinv(Xn*Xn')*Xn,m+1);
En = Yn - ttm(Btil,Xn',m+1);
[lambda Sig] = kroncov(En);
Btil = double(Btil);
for i = 1:m
    Sinvhalf{i} = inv(sqrtm(Sig{i}));
end
for i = 1:m
    M = lambda*Sig{i};
    idx = setdiff(1:m+1,i);
    Ysn = ttm(Yn,Sinvhalf(idx(1:end-1)),idx(1:end-1));
    idxprod = r(i)/n/prodr;
    YsnYsn = ttt(Ysn,Ysn,idx).*idxprod;
    U = YsnYsn.data - M;
    Gamma{i} = manifold1D(M,U,u(i));
    PGamma{i} = Gamma{i}*Gamma{i}';
end
Bhat = ttm(ttm(Yn,PGamma,1:m),pinv(Xn*Xn')*Xn,m+1);
Bhat = double(Bhat);
