function Pval = Pval_adjust(Tval, df)
r = size(Tval);
m = length(r);
prodr = prod(r);
Praw = tcdf(abs(Tval),df);
Praw = 1-Praw;
Prawvec = reshape(Praw,[prodr 1]);
[Psort idx] = sort(Prawvec);
y = 1:prodr;
Qraw = prodr*Psort./y';
Qadj = zeros(prodr,1);
for i=1:prodr
    Qadj(i) = min(Qraw(i:end));
end
Pval = Qadj;
Pval(idx) = Qadj;
Pval = 2*reshape(Pval,r);
