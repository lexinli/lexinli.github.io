function [bic_val, u] = manifold1D_bic(M,U,multiD,n,bic_max)
% select dimension of the M-envelope of span(U)
% using M and inv(M+U)
% multiD is 1 for univariate regression; 
% multiD is # of response (predictor) for predictor (response) envelope;
p = size(M,2);
Mnew = M;
Unew = U;
G = zeros(p,bic_max);
G0 = eye(p);
for k=1:bic_max
    if k == p
        break;
    end
    gk = first1D(Mnew,Unew);
    G(:,k)=G0*gk;
    G0 = null(G(:,1:k)');
    Mnew = G0'*M*G0;
    Unew = G0'*U*G0;
end

bic_val = zeros(bic_max,1);

for k=1:bic_max
    Ghat = G(:,1:k);
    Ghat0 = null(Ghat');
    bic_val(k) = n*( logdet(Ghat'*M*Ghat)+logdet(Ghat0'*(M+U)*Ghat0) ) + log(n)*k*multiD;
end
[minbic, u] = min(bic_val);

