
g2z<-function(z,cuts,nc){
 g<-0*z
 for(c in 1:nc){g<-g+ifelse(z>cuts[c],1,0)}
g} 

rtnorm<-function(n,mu,sigma,L,U){
   l.prob<-pnorm(L,mu,sigma)
   u.prob<-pnorm(U,mu,sigma)
qnorm(runif(n,l.prob,u.prob),mu,sigma)}

Bayes.DR<-function(y,X,slices=7,d=1,ANOVA=T,
                   in.prob.a=1,in.prob.b=1,
                   iterations=5000,burnin=1000,update=100){

   library(mvtnorm)
   library(fields)   
   library(dr)

   small<-0.01
   eps<-0.1
   nc<-slices
   base<-1:d
   n<-length(y)
   p<-ncol(X)

   mean.x<-apply(X,2,mean,na.rm=T)
   sd.x<-apply(X,2,sd,na.rm=T)
   for(j in 1:p){
     X[,j]<-(X[,j]-mean.x[j])/sd.x[j]
   }
   y<-(y-mean(y,na.rm=T))/sd(y,na.rm=T)

   sd.cuts<-3*sqrt(p)
   cuts<-sd.cuts*qnorm(seq(0,1,length=nc+1))
   z<-matrix(rnorm(n*d),n,d)
   sir<-dr(y~x, method="sir", nslices=5)
   beta<-as.matrix(sir$evectors[,1:d])

   z<-X%*%beta

   inout<-prec.beta<-matrix(1,p,d)
   if(d>1){for(l in 2:d){
     beta[base[l-1],l:d]<-inout[base[l-1],l:d]<-0  
     prec.beta[,l]<-1/ifelse(inout[,l],1,small)^2
   }}

   in.prob<-rep(1,d)
   g<-g2z(z,cuts,nc)

   mu<-array(rnorm(nc^d),rep(nc,d))
   taue<-1/var(y)
   tauz<-rep(1,d)
   int<-mean(y)
   taus<-1
   tXX<-t(X)%*%X

   mu1<-mu2<-mu3<-mu4<-rep(0,nc)
   tau1<-tau2<-tau3<-tau4<-1
   as<-bs<-20

   keep.beta<-array(0,c(iterations,p,d))
   inout.mn<-rep(0,p)

   for(i in 1:iterations){

     #fill in the zeros:
     int<-rnorm(1,mean(y-mu[g]),1/sqrt(taue*n))
     r<-y-int

     #update z
     Xbeta<-X%*%beta
     sige<-1/sqrt(taue)
     sigz<-1/sqrt(tauz)


     #update z
     for(l in 1:d){
       ppp<-matrix(0,n,nc)
       for(j in 1:nc){
         ggg<-g;ggg[,l]<-j
         ppp[,j]<-(pnorm(cuts[j+1],Xbeta[,l],sigz[l])-
                   pnorm(cuts[j],Xbeta[,l],sigz[l]))*
                   dnorm(r,mu[ggg],sige)
       }
       for(j in 1:n){
         if(!is.na(sum(ppp[j,]))){
           if(sum(ppp[j,])>0){
             g[j,l]<-sample(1:nc,1,prob=ppp[j,])
       }}}    

       z[,l]<-rtnorm(n,Xbeta[,l],sigz[l],cuts[g[,l]],cuts[g[,l]+1])
     }

     #update mu
     V<-M<-array(0,rep(nc,d))
     if(d==1){for(j in 1:nc){
       V[j]<-taue*sum(g==j)+taus*taue
       M[j]<-taue*sum(r[g==j])
     }}
     if(d==2){for(j1 in 1:nc){for(j2 in 1:nc){
       these<-(g[,1]==j1 & g[,2]==j2)
       V[j1,j2]<-taue*sum(these)+taue*taus
       M[j1,j2]<-taue*sum(r[these]) + taue*taus*(mu1[j1]+mu2[j2])
     }}}
     if(d==3){for(j1 in 1:nc){for(j2 in 1:nc){for(j3 in 1:nc){
       these<-(g[,1]==j1 & g[,2]==j2 & g[,3]==j3)
       V[j1,j2,j3]<-taue*sum(these)+taue*taus
       M[j1,j2,j3]<-taue*sum(r[these]) + 
                    taue*taus*(mu1[j1]+mu2[j2]+mu3[j3])
     }}}}
     if(d==4){for(j1 in 1:nc){for(j2 in 1:nc){for(j3 in 1:nc){for(j4 in 1:nc){
       these<-(g[,1]==j1 & g[,2]==j2 & g[,3]==j3 & g[,4]==j4)
       V[j1,j2,j3,j4]<-taue*sum(these)+taue*taus
       M[j1,j2,j3,j4]<-taue*sum(r[these]) + 
                    taue*taus*(mu1[j1]+mu2[j2]+mu3[j3]+mu[j4])
     }}}}}
     mu<-M/V+array(rnorm(nc^d),rep(nc,d))/sqrt(V)

     #update variances
     SS1<-sum((r-mu[g])^2)+tau1*sum(mu1^2)+tau2*sum(mu2^2)+tau3*sum(mu3^2)+tau4*sum(mu4^2)
     SS2<-0
     if(d==1){SS2<-sum(mu^2)}
     if(d==2){for(j1 in 1:nc){for(j2 in 1:nc){
       SS2<-SS2+(mu[j1,j2]-mu1[j1]-mu2[j2])^2
     }}}
     if(d==3){for(j1 in 1:nc){for(j2 in 1:nc){for(j3 in 1:nc){
       SS2<-SS2+(mu[j1,j2,j3]-mu1[j1]-mu2[j2]-mu3[j3])^2
     }}}}
     if(d==4){for(j1 in 1:nc){for(j2 in 1:nc){for(j3 in 1:nc){for(j4 in 1:nc){
       SS2<-SS2+(mu[j1,j2,j3,j4]-mu1[j1]-mu2[j2]-mu3[j3]-mu4[j4])^2
     }}}}}
     df<-n+nc^d+ifelse(ANOVA,d*nc,0)
     taue<-rgamma(1,df/2+eps,SS1/2+taus*SS2/2+eps)
     taus<-rgamma(1,(nc^d)/2+eps,taue*SS2/2+eps)

     if(!ANOVA){mu1<-mu2<-mu3<-mu4<-rep(0,nc)}
     if(d==2 & ANOVA){
       for(j in 1:nc){
         V<-1/(nc*taus*taue+taue*tau1)
         M<-sum(taus*taue*(mu[j,]-mu2))
         mu1[j]<-rnorm(1,V*M,sqrt(V))
     
         V<-1/(nc*taue*taus+taue*tau2)
         M<-sum(taus*taue*(mu[,j]-mu1))
         mu2[j]<-rnorm(1,V*M,sqrt(V))
       }
       tau1<-rgamma(1,nc/2+eps,taue*sum(mu1^2)/2+eps)
       tau2<-rgamma(1,nc/2+eps,taue*sum(mu2^2)/2+eps)
     }
   
     if(d==3 & ANOVA){
       for(j in 1:nc){
         V<-1/(nc*nc*taus*taue+taue*tau1)
         M<-0
         for(j1 in 1:nc){for(j2 in 1:nc){
           M<-M+taus*taue*(mu[j,j1,j2]-mu2[j1]-mu3[j2])
         }}
         mu1[j]<-rnorm(1,V*M,sqrt(V))
     
         V<-1/(nc*nc*taue*taus+taue*tau2)
         M<-0
         for(j1 in 1:nc){for(j2 in 1:nc){
           M<-M+taus*taue*(mu[j1,j,j2]-mu1[j1]-mu3[j2])
         }}
         mu2[j]<-rnorm(1,V*M,sqrt(V))

         V<-1/(nc*nc*taue*taus+taue*tau3)
         M<-0
         for(j1 in 1:nc){for(j2 in 1:nc){
           M<-M+taus*taue*(mu[j1,j2,j]-mu1[j1]-mu2[j2])
         }}
         mu3[j]<-rnorm(1,V*M,sqrt(V))
       }
       tau1<-rgamma(1,nc/2+eps,taue*sum(mu1^2)/2+eps)
       tau2<-rgamma(1,nc/2+eps,taue*sum(mu2^2)/2+eps)
       tau3<-rgamma(1,nc/2+eps,taue*sum(mu3^2)/2+eps)
       if(is.na(tau1)){tau1<-10}
       if(is.na(tau2)){tau2<-10}
       if(is.na(tau3)){tau3<-10}
     }
   
     if(d==4 & ANOVA){
       for(j in 1:nc){
         V<-1/(nc*nc*nc*taus*taue+taue*tau1)
         M<-0
         for(j1 in 1:nc){for(j2 in 1:nc){for(j3 in 1:nc){
           M<-M+taus*taue*(mu[j,j1,j2,j3]-mu2[j1]-mu3[j2]-mu4[j3])
         }}}
         mu1[j]<-rnorm(1,V*M,sqrt(V))
     
         V<-1/(nc*nc*nc*taue*taus+taue*tau2)
         M<-0
         for(j1 in 1:nc){for(j2 in 1:nc){for(j3 in 1:nc){
           M<-M+taus*taue*(mu[j1,j,j2,j3]-mu1[j1]-mu3[j2]-mu4[j3])
         }}}
         mu2[j]<-rnorm(1,V*M,sqrt(V))

         V<-1/(nc*nc*nc*taue*taus+taue*tau3)
         M<-0
         for(j1 in 1:nc){for(j2 in 1:nc){for(j3 in 1:nc){
           M<-M+taus*taue*(mu[j1,j2,j,j3]-mu1[j1]-mu2[j2]-mu4[j3])
         }}}
         mu3[j]<-rnorm(1,V*M,sqrt(V))

         V<-1/(nc*nc*nc*taue*taus+taue*tau3)
         M<-0
         for(j1 in 1:nc){for(j2 in 1:nc){for(j3 in 1:nc){
           M<-M+taus*taue*(mu[j1,j2,j,j3]-mu1[j1]-mu2[j2]-mu3[j3])
         }}}
         mu4[j]<-rnorm(1,V*M,sqrt(V))
       }
       tau1<-rgamma(1,nc/2+eps,taue*sum(mu1^2)/2+eps)
       tau2<-rgamma(1,nc/2+eps,taue*sum(mu2^2)/2+eps)
       tau3<-rgamma(1,nc/2+eps,taue*sum(mu3^2)/2+eps)
       tau4<-rgamma(1,nc/2+eps,taue*sum(mu4^2)/2+eps)
       if(is.na(tau1)){tau1<-10}
       if(is.na(tau2)){tau2<-10}
       if(is.na(tau3)){tau3<-10}
       if(is.na(tau4)){tau4<-10}
     }

     #update beta/tauz
     for(l in 1:d){
       V<-solve(tauz[l]*tXX + diag(prec.beta[,l]))
       M<-tauz[l]*V%*%t(X)%*%z[,l]    
       if(i>5){beta[,l]<-M+t(chol(V))%*%rnorm(p)}
       big<-0*n*100+eps
       tauz[l]<-rgamma(1,n/2+eps,
                       sum((z[,l]-X%*%beta[,l])^2)/2+eps)
       if(is.na(tauz[l])){tauz[l]<-10}
       p1<-in.prob[l]*dnorm(beta[,l],0,1)
       p0<-(1-in.prob[l])*dnorm(beta[,l],0,small)
       inout[,l]<-rbinom(p,1,p1/(p0+p1))
       if(d>1){for(j in 2:d){inout[base[j-1],j:d]<-0}}
       prec.beta[,l]<-1/ifelse(inout[,l],1,small)^2

     }

     suc<-in.prob.a;fail<-in.prob.b
     for(j in 1:d){
       suc<-suc+sum(inout[,j])
       fail<-fail+sum(1-inout[,j])-(j-1)
     }
     in.prob[1:d]<-rbeta(1,suc,fail)

     if(i>burnin){
       inout.mn<-inout.mn+apply(inout,1,max)/(iterations-burnin)
     }

     keep.beta[i,,]<-beta

     if(i%%update==0){
       par(mfrow=c(1,1))
       if(d==1){ plot(beta,main=i)}
       if(d==2){ 
          plot(beta,col=0,main=i)
          text(beta[,1],beta[,2],1:p)
       }
       if(d>2){
         image.plot(1:d,1:p,t(beta),
         xlab="Direction",
         ylab="Covariate",main=i)
       }
     }
   }

  proj<-array(0,c(iterations,p,p))
  for(i in burnin:iterations){
    X<-keep.beta[i,,]
    proj[i,,]<-X%*%ginv(t(X)%*%X)%*%t(X)
  }
  P<-apply(proj[burnin:iterations,,],2:3,mean)

  
list(A=eigen(P)$vectors[,1:d],
     P=P,
     A.samples=keep.beta,
     in.prob=inout.mn
)}

